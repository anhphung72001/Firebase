package com.example;

import java.io.IOException;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.google.auth.oauth2.GoogleCredentials;




public class Getdata {
    public static void main(String[] args) throws IOException {
        // Khởi tạo Firebase
        FirebaseInitialize.initialize();

        // Tham chiếu đến node trong Realtime Database
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("test/float");

        // Lắng nghe dữ liệu
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Xử lý dữ liệu lấy được
                Object data = dataSnapshot.getValue();
                System.out.println(data);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.err.println("Lỗi: " + databaseError.getMessage());
            }
        });
    }
}

